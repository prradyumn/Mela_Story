"""Build dist/The_Mela_Before_Sunset.html: one self-contained file (all images, fonts, audio and JS inlined).
Run from this folder:  python3 build.py
"""
import base64, re, os, json
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
def b64(p): return base64.b64encode(open(p, 'rb').read()).decode()
css = open('style.css').read()
css = re.sub(r"url\(f/([^)]+)\)", lambda m: f"url(data:font/woff2;base64,{b64('f/' + m.group(1))})", css)
css = re.sub(r"url\(a/([^)]+)\)", lambda m: f"url(data:image/webp;base64,{b64('a/' + m.group(1))})", css)
emb = {}
for f in sorted(os.listdir('a')): emb[os.path.splitext(f)[0]] = 'data:image/webp;base64,' + b64('a/' + f)
for f in sorted(os.listdir('au')): emb[os.path.splitext(f)[0]] = 'data:audio/mpeg;base64,' + b64('au/' + f)
lay = json.load(open('layout.json'))
open('layout.js', 'w').write('window.LAYOUT_DEFAULT = ' + json.dumps(lay) + ';\n')
html = open('index.html').read()
html = html.replace('<link rel="stylesheet" href="style.css">', '<style>' + css + '</style>')
scripts = re.findall(r'<script src="([^"]+)"></script>', html)
for js in scripts:
    pre = '<script>window.EMBED=' + json.dumps(emb) + ';</script>\n' if js == 'engine.js' else ''
    html = html.replace(f'<script src="{js}"></script>', pre + '<script>' + open(js).read() + '</script>')
os.makedirs('dist', exist_ok=True)
open('dist/The_Mela_Before_Sunset.html', 'w').write(html)
print('dist/The_Mela_Before_Sunset.html', round(len(html) / 1e6, 1), 'MB')
