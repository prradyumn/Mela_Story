window.LAYOUT_DEFAULT = {"version": 1, "items": {}, "text": {}};
